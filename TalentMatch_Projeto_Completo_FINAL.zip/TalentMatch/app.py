from flask import Flask, render_template, request, redirect, url_for, session, flash
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
import os
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'segredo-talento-2025'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database/talentmatch.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

class Usuario(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    tipo = db.Column(db.String(20))
    nome = db.Column(db.String(100))
    email = db.Column(db.String(100), unique=True)
    senha = db.Column(db.String(200))
    criado_em = db.Column(db.DateTime, default=datetime.utcnow)

class Vaga(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    titulo = db.Column(db.String(100))
    descricao = db.Column(db.Text)
    empresa_id = db.Column(db.Integer)
    localizacao = db.Column(db.String(100))
    salario = db.Column(db.String(50))
    beneficios = db.Column(db.String(200))
    data_publicacao = db.Column(db.DateTime, default=datetime.utcnow)
    visualizacoes = db.Column(db.Integer, default=0)
    candidaturas = db.Column(db.Integer, default=0)

class Candidatura(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    usuario_id = db.Column(db.Integer)
    vaga_id = db.Column(db.Integer)
    data = db.Column(db.DateTime, default=datetime.utcnow)
    status = db.Column(db.String(50), default='Enviado')

class Log(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    acao = db.Column(db.String(200))
    usuario = db.Column(db.String(100))
    data = db.Column(db.DateTime, default=datetime.utcnow)

@app.before_first_request
def criar_banco():
    db.create_all()
    if not Usuario.query.filter_by(email='master@talentmatch.com').first():
        master = Usuario(
            tipo='master',
            nome='Administrador Master',
            email='master@talentmatch.com',
            senha=generate_password_hash('master123')
        )
        db.session.add(master)
        db.session.commit()

@app.route('/')
def home():
    vagas = Vaga.query.order_by(Vaga.data_publicacao.desc()).limit(5).all()
    return render_template('index.html', vagas=vagas)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        senha = request.form['senha']
        usuario = Usuario.query.filter_by(email=email).first()
        if usuario and check_password_hash(usuario.senha, senha):
            session['usuario_id'] = usuario.id
            session['usuario_tipo'] = usuario.tipo
            flash('Login realizado com sucesso!', 'success')
            if usuario.tipo == 'master':
                return redirect(url_for('painel_master'))
            elif usuario.tipo == 'empresa':
                return redirect(url_for('publicar_vaga'))
            else:
                return redirect(url_for('painel_candidato'))
        else:
            flash('Credenciais inválidas.', 'danger')
    return render_template('login.html')

@app.route('/cadastro', methods=['GET', 'POST'])
def cadastro():
    if request.method == 'POST':
        tipo = request.form['tipo']
        nome = request.form['nome']
        email = request.form['email']
        senha = generate_password_hash(request.form['senha'])
        if Usuario.query.filter_by(email=email).first():
            flash('E-mail já cadastrado.', 'warning')
            return redirect(url_for('cadastro'))
        novo_usuario = Usuario(tipo=tipo, nome=nome, email=email, senha=senha)
        db.session.add(novo_usuario)
        db.session.commit()
        flash('Cadastro realizado com sucesso! Faça login para continuar.', 'success')
        return redirect(url_for('login'))
    return render_template('cadastro.html')

@app.route('/logout')
def logout():
    session.clear()
    flash('Você saiu da sua conta.', 'info')
    return redirect(url_for('login'))

@app.route('/painel-candidato')
def painel_candidato():
    if 'usuario_id' not in session or session.get('usuario_tipo') != 'candidato':
        return redirect(url_for('login'))
    return render_template('painel-candidato.html')

@app.route('/painel-master')
def painel_master():
    if 'usuario_id' not in session or session.get('usuario_tipo') != 'master':
        return redirect(url_for('login'))
    return render_template('painel-master.html')

@app.route('/publicar-vaga', methods=['GET', 'POST'])
def publicar_vaga():
    if 'usuario_id' not in session or session.get('usuario_tipo') != 'empresa':
        return redirect(url_for('login'))
    if request.method == 'POST':
        nova = Vaga(
            titulo=request.form['titulo'],
            descricao=request.form['descricao'],
            empresa_id=session['usuario_id'],
            localizacao=request.form['localizacao'],
            salario=request.form['salario'],
            beneficios=request.form['beneficios']
        )
        db.session.add(nova)
        db.session.commit()
        flash('Vaga publicada com sucesso!', 'success')
        return redirect(url_for('publicar_vaga'))
    return render_template('publicar-vaga.html')

if __name__ == '__main__':
    app.run(debug=True)
