# Os modelos estão definidos diretamente no app.py neste projeto inicial.
