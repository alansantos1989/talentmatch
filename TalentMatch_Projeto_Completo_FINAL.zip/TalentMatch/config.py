import os

class Config:
    SECRET_KEY = os.environ.get("SECRET_KEY", "segredo-talento-2025")
    SQLALCHEMY_DATABASE_URI = "sqlite:///database/talentmatch.db"
    SQLALCHEMY_TRACK_MODIFICATIONS = False
